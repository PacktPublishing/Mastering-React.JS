import React from 'react';

class Dashboard extends React.Component {
  render() {
    return <h1>Dashboard</h1>;
  }
}

export default Dashboard;
