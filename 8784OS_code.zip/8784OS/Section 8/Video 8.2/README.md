# mastering-react
Mastering React sample application

# Installation on Mac for sending emails
1. Install librsvg: `brew install librsvg`
2. Install [XQuartz](http://xquartz.macosforge.org/landing/)
3. `export PKG_CONFIG_PATH=/opt/X11/lib/pkgconfig`
