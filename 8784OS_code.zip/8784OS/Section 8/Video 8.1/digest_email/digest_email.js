import React from 'react';

class DigestEmail extends React.Component {
  render() {
    return (
      <html>
        <body>
          <h1>Storekeeper Digest Email</h1>
        </body>
      </html>
    );
  }
}

export default DigestEmail;
