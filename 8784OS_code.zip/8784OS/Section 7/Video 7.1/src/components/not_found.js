import React from 'react';

class NotFound extends React.Component {
  render() {
    return <div>Not Found</div>;
  }
}

export default NotFound;
