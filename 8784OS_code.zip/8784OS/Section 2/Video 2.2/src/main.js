import React from 'react';
import App from './components/app';

React.render(<App />, document.querySelector('#anchor'));
